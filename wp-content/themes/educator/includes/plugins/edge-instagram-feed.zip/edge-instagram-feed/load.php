<?php

include_once 'lib/edgt-instagram-api.php';
include_once 'widgets/load.php';