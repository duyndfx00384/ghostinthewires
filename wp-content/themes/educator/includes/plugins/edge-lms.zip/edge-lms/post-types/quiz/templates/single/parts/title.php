<h4 class="edgt-quiz-single-title">
    <?php the_title(); ?>
</h4>