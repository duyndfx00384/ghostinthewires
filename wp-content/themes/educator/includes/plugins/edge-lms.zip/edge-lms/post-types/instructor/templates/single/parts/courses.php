<?php
echo educator_edge_execute_shortcode('edgt_course_list', $courses);