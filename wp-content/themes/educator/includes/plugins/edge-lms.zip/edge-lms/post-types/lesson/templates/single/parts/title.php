<h3>
    <?php the_title(); ?>
</h3>