<?php

get_header();

educator_edge_get_title();

edgt_lms_get_single_instructor();

get_footer();