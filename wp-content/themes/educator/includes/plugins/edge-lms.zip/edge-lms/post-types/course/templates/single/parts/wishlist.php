<span class="edgt-course-wishlist-wrapper">
	<a href="javascript:void(0)" class="edgt-course-wishlist" data-course-id="<?php echo get_the_ID(); ?>">
        <i class="<?php echo esc_attr($wishlist_icon); ?>"></i>
    </a>
</span>


