<div class="edgt-course-content">
    <h3 class="edgt-course-content-title"><?php esc_html_e('About this course', 'edge-lms') ?></h3>
    <?php the_content(); ?>
</div>