<div class="edgt-course-content">
    <?php the_content(); ?>
</div>