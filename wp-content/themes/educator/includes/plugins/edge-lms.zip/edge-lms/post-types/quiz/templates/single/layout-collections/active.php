<div class="edgt-quiz-active-wrapper">
    <div class="edgt-quiz-title-wrapper">
        <?php edgt_lms_get_cpt_single_module_template_part('templates/single/parts/title', 'quiz', '', $params); ?>
    </div>
    <div class="edgt-quiz-info-top-wrapper">
        <?php edgt_lms_get_cpt_single_module_template_part('templates/single/parts/info-top', 'quiz', 'active', $params); ?>
    </div>
    <div class="edgt-quiz-question-wrapper">
        <?php edgt_lms_get_cpt_single_module_template_part('templates/single/layout-collections/default', 'question', '', $params); ?>
    </div>
</div>