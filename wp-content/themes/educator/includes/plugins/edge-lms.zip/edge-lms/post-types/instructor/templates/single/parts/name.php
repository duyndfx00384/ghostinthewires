<h3 itemprop="name" class="edgt-name entry-title">
    <?php the_title(); ?>
</h3>