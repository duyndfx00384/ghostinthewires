<?php

include_once EDGE_LMS_CPT_PATH.'/quiz/quiz-register.php';
include_once EDGE_LMS_CPT_PATH.'/quiz/helper-functions.php';