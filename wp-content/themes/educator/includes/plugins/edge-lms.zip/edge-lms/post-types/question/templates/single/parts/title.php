<?php
//$question = isset($question_id) ? $question_id : get_the_ID();
?>
<h5 class="edgt-question-single-title">
    <?php echo get_the_title($question_id); ?>
</h5>