<div class="edgt-course-action <?php if(edgt_lms_user_has_course()){ echo 'edgt-course-progress';} ?>">
    <?php edgt_lms_get_buy_form(); ?>
</div>