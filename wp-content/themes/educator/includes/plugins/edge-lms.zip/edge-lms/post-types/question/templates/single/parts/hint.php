<div class="edgt-question-hint-holder">
    <span class="edgt-hint-value">
        <?php echo esc_html($hint_value); ?>
    </span>
</div>