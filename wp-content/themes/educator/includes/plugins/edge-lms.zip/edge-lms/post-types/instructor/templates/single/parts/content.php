<div class="edgt-instructor-single-content">
	<?php the_content(); ?>
</div>