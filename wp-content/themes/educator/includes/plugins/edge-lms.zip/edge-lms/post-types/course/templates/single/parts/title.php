<h2 class="edgt-course-single-title">
    <?php the_title(); ?>
</h2>