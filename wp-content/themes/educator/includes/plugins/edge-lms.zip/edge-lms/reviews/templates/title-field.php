<div class="edgt-comment-input-title">
	<label><?php esc_html_e('Title of your Review', 'edge-lms') ?></label>
	<input id="title" name="edgt_comment_title" class="edgt-input-field" type="text" placeholder=""/>
</div>