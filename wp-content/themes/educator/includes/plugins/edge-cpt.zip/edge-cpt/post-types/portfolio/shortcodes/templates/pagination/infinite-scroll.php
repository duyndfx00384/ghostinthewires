<?php if($query_results->max_num_pages > 1) { ?>
	<div class="edgt-pl-loading">
		<div class="edgt-pl-loading-bounce1"></div>
		<div class="edgt-pl-loading-bounce2"></div>
		<div class="edgt-pl-loading-bounce3"></div>
	</div>
<?php }