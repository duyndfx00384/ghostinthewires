<?php

include_once EDGE_CORE_CPT_PATH.'/masonry-gallery/masonry-gallery-register.php';
include_once EDGE_CORE_CPT_PATH.'/masonry-gallery/helper-functions.php';
include_once EDGE_CORE_CPT_PATH.'/masonry-gallery/shortcodes/shortcodes-functions.php';