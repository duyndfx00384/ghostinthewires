<div class="edgt-ps-info-item edgt-ps-content-item">
    <?php the_content(); ?>
</div>