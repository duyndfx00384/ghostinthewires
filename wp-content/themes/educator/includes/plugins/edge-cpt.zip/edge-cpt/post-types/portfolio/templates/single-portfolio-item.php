<?php

get_header();

educator_edge_get_title();

edgt_core_get_single_portfolio();

get_footer();