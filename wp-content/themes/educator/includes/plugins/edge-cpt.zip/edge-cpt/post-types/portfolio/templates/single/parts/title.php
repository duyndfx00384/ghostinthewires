<div class="edgt-ps-info-item edgt-ps-item-title">
    <h2 class="edgt-ps-title"> <?php the_title(); ?> </h2>
</div>