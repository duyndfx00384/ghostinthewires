<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/boxes/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/boxes/boxes.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/boxes/boxes-item.php';