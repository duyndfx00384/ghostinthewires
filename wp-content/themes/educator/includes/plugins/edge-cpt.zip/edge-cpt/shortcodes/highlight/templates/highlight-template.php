<?php
/**
 * Highlight shortcode template
 */
?>

<span class="edgt-highlight" <?php educator_edge_inline_style($highlight_style);?>>
	<?php echo esc_html($content);?>
</span>