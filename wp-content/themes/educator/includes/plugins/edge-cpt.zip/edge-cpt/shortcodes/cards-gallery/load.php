<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/cards-gallery/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/cards-gallery/cards-gallery.php';