<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/button/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/button/button.php';