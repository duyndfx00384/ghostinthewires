<<?php echo esc_attr($title_tag); ?> class="edgt-custom-font-holder <?php echo esc_attr($holder_classes); ?>" <?php educator_edge_inline_style($holder_styles); ?> <?php echo educator_edge_get_inline_attrs($holder_data); ?>>
	<?php echo esc_html($title); ?>
</<?php echo esc_attr($title_tag); ?>>