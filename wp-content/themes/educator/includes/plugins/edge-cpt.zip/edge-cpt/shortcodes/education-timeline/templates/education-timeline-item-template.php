<div class="edgt-tml-item-holder">
    <span class="edgt-tml-item-circle"></span>
    <div class="edgt-tml-item-content">
        <div class="edgt-tml-item-title"><?php echo esc_html($title);?></div>
        <div class="edgt-tml-item-subtitle"><?php echo  esc_html($subtitle);?></div>
    </div>
</div>