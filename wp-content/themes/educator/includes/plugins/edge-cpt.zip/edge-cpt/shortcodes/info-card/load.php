<?php
include_once EDGE_CORE_SHORTCODES_PATH.'/info-card/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/info-card/info-card.php';