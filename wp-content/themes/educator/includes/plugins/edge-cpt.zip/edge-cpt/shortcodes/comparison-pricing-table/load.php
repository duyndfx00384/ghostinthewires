<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/comparison-pricing-table/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/comparison-pricing-table/comparison-pricing-table.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/comparison-pricing-table/comparison-pricing-table-item.php';