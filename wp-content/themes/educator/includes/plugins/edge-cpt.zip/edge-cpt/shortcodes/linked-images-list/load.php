<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/linked-images-list/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/linked-images-list/linked-images-list.php';