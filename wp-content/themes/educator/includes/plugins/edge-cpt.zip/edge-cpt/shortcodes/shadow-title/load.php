<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/shadow-title/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/shadow-title/shadow-title.php';