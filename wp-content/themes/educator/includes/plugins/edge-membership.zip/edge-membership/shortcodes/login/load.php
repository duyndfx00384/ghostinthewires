<?php
include_once EDGE_MEMBERSHIP_SHORTCODES_PATH.'/login/functions.php';
include_once EDGE_MEMBERSHIP_SHORTCODES_PATH.'/login/login.php';