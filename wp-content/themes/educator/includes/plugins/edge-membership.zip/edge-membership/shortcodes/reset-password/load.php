<?php

include_once EDGE_MEMBERSHIP_SHORTCODES_PATH.'/reset-password/functions.php';
include_once EDGE_MEMBERSHIP_SHORTCODES_PATH.'/reset-password/reset-password.php';