<div class="edgt-register-notice">
	<h5 class="edgt-register-notice-title"><?php echo esc_html($message); ?></h5>
	<a href="#" class="edgt-login-action-btn edgt-modal-opener" data-modal="login" data-title="<?php esc_html_e('LOGIN', 'edgt-membership'); ?>"><?php esc_html_e('LOGIN', 'edgt-membership'); ?></a>
</div>