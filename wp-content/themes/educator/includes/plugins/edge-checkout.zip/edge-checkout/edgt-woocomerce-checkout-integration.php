<?php
/*
Plugin Name: Edge Woocommerce Checkout Integration
Description: Plugin that adds custom post type to woocommerce checkout
Author: Edge Themes
Version: 1.0
*/

include_once 'load.php';
